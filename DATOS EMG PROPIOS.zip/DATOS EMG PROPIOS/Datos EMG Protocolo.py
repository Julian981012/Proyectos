import serial
import time
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime

# Configuración del puerto serial
arduino = serial.Serial('COM3', 9600, timeout=0.01)  # Puerto serial y velocidad de transmisión
time.sleep(2)  # Esperar a que se establezca la comunicación

numero_datos = 5000  # Número de datos a adquirir
ECG = np.ndarray((0), dtype=int)  # Arreglo para almacenar la señal EMG

while ECG.shape[0] < numero_datos: 
    datos = arduino.readlines(arduino.inWaiting())  # Leer datos del puerto serial
    datos_por_leer = len(datos)
  
    if len(datos) > numero_datos:
        datos = datos[0:numero_datos]
        valores_leidos = np.zeros(numero_datos, dtype=int)
    else:
        valores_leidos = np.zeros(datos_por_leer, dtype=int)

    posicion = 0
    for dato in datos:
        try:
            valores_leidos[posicion] = int(dato.decode().strip())
        except:
            valores_leidos[posicion] = valores_leidos[posicion-1]
        posicion += 1
    
    ECG = np.append(ECG, valores_leidos)
    time.sleep(2)

ECG = ECG[0:numero_datos]

# Generar un nombre de archivo único basado en la fecha y hora actual
fecha_hora_actual = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
nombre_archivo = f'datos_emg_{fecha_hora_actual}.txt'

# Guardar los datos en un archivo de texto con un nombre único
np.savetxt(nombre_archivo, ECG)

# Graficar la señal EMG
plt.plot(ECG)
plt.savefig(f'graficoECG_{fecha_hora_actual}.png')
plt.show()

arduino.close()  # Cerrar puerto serial